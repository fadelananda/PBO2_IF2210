package enums;

public enum Elements {
    FIRE,
    WATER,
    ELECTRIC,
    GROUND,
    ICE
}
