package GUI;

public interface GameObject {
    public void render(RenderHandler renderer, int xzoom, int yzoom);
    public void update(Game game);
}
