package interfaces;

public interface MoveAction {
    void moveUp();
    void moveDown();
    void moveRight();
    void moveLeft();
}
