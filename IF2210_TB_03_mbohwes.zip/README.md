# Tugas Besar 2 Pemrograman Berorientasi Objek IF2210
> Willy Wangky and The Engimon Factory in JAVA

* [Cara Pengunaan](#cara_penggunaan)
* [Kontributor](#kontributor)

## Cara Penggunaan(menggunakan Intellij IDEA)
* Download/clone repositori ini terlebih dahulu
* Buka Intellij, lalu setting SDK terlebih dahulu
* Jadikan folder PBO2_IF2210 ini sebagai source root
* buka folder src, lalu Run kelas Main
* Game Engimon siap dimainkan
* <img src="https://user-images.githubusercontent.com/63132659/116109545-167ada80-a6df-11eb-928e-d773627c0974.png" width="500">


## Kontributor
* Pratama Andiko (13519112)
* Bintang Fajrianto (13519138)
* Fabian Savero Diaz Pranoto (13519140)
* Fadel Ananda Dotty (13519146)
* Ryandito Diandaru (13519157)
* Kadek Surya Mahardika (13519165)
